from . import glm
from . import glm_typing
typing = glm_typing
__version__ = glm.__version__
